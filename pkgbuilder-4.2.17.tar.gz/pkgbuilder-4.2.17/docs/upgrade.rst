==============
upgrade module
==============

:Author: Chris Warrick <chris@chriswarrick.com>
:Copyright: © 2011-2018, Chris Warrick.
:License: BSD (see /LICENSE or :doc:`Appendix B <LICENSE>`.)
:Date: 2018-03-25
:Version: 4.2.17

.. index:: upgrade
.. index:: Syu
.. versionadded:: 2.1.0.0
.. versionchanged:: 3.0.0
    Class removed, its methods became module-level functions
.. automodule:: pkgbuilder.upgrade
   :members:
