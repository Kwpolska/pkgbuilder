===========
main module
===========
:Author: Kwpolska
:Copyright: See Appendix B.
:Date: 2012-08-01
:Version: 2.1.3.0

.. index:: main
.. versionadded:: 2.1.3.0
.. module:: main

main()
======
The main routine.  Please do not use it unless you have a good reason.
