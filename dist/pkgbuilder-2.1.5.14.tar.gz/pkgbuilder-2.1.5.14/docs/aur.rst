======================
aur module (AUR class)
======================
:Author: Kwpolska
:Copyright: © 2011-2013, Kwpolska.
:License: BSD (see /LICENSE or :doc:`Appendix B <LICENSE>`.)
:Date: 2013-01-09
:Version: 2.1.5.14

.. index:: AUR; RPC
.. index:: RPC
.. versionadded:: 2.1.0.0
.. automodule:: pkgbuilder.aur
   :members:
