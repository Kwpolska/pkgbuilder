==========================
utils module (Utils class)
==========================

:Author: Kwpolska
:Copyright: © 2011-2012, Kwpolska.
:License: BSD (see /LICENSE or :doc:`Appendix B <LICENSE>`.)
:Date: 2013-01-09
:Version: 2.1.5.14

.. index:: Utils
.. automodule:: pkgbuilder.utils
   :members:
