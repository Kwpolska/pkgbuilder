===============================
Appendix E. TODO for PKGBUILDer
===============================
:Author: Kwpolska
:Copyright: See Appendix B.
:Date: 2013-01-09
:Version: 2.1.5.14

.. index:: TODO

* [proposition] an app for desktop AUR magic

  In Qt.  And it will be a separate project, if any.  Basically, it would
  include most features of the aurweb, but without the need for a browser and
  in a more readable format.

  Suggested name: aurqt.

  Update: we’re quite far in the progress.  Bonus info: when aurqt will go
  0.1.0, PB will go 3.0.0 (dropping the fouth digit.)  But #22 will need to
  be resolved first.  I might also want to bump aurqt to 1.0.0 quicker.

-- Kwpolska 2012-09-29T19:00:00Z
