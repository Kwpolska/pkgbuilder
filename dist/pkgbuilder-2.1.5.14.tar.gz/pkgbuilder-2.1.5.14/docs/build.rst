==========================
build module (Build class)
==========================
:Author: Kwpolska
:Copyright: © 2011-2013, Kwpolska.
:License: BSD (see /LICENSE or :doc:`Appendix B <LICENSE>`.)
:Date: 2013-01-09
:Version: 2.1.5.14

.. index:: Build
.. versionadded:: 2.1.0.0
.. automodule:: pkgbuilder.build
   :members:
