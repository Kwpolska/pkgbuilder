=============================
Sample scripts for PKGBUILDer
=============================

Those are some sample scripts utilizing PKGBUILDer for doing stuff.  The
current list can be found in the docs: <http://pkgbuilder.rtfd.org>.
