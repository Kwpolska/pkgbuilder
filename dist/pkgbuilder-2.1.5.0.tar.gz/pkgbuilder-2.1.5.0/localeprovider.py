# A module only for gettext locale provision.
translationcheat = _('usage') + _('positional arguments') + _('optional arguments') + _('show this help message and exit')
