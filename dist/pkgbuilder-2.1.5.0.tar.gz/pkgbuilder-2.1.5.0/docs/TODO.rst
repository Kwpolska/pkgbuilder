===============================
Appendix E. TODO for PKGBUILDer
===============================
:Author: Kwpolska
:Copyright: See Appendix B.
:Date: 2012-10-05
:Version: 2.1.5.0

.. index:: TODO

* [proposition] an app for desktop AUR magic

  In Qt.  And it will be a separate project, if any.  Basically, it would
  include most features of the aurweb, but without the need for a browser and
  in a more readable format.

  Suggested name: aurqt.

-- Kwpolska 2012-09-29T19:00:00Z
