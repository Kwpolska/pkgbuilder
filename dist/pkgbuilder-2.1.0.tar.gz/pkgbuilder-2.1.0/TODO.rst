===================
TODO for PKGBUILDer
===================
:Info: This is a TODO list for PKGBUILDer.
:Author: Kwpolska <kwpolska@kwpolska.tk>
:Date: 2011-09-20
:Version: 2.1.0

I have a few cool (and impossible) ideas for PKGBUILDer.  This file
would list them.  If you know Python, you can write them and send
me a patch.

 * pacmanization:
       extra/gnutls 3.0.3-1 [1.33 MB] [installed: 3.0.2-1]

