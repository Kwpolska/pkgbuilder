===========
main module
===========
:Author: Kwpolska
:Copyright: © 2011-2012, Kwpolska.
:License: BSD (see /LICENSE or :doc:`Appendix B <LICENSE>`.)
:Date: 2012-09-21
:Version: 2.1.4.6

.. index:: main
.. versionadded:: 2.1.3.0
.. module:: main

main()
======
The main routine.  Please do not use it unless you have a good reason.
